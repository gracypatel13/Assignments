package com.employee;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Services")
public class ServicesServlet extends HttpServlet{

	private empDao emp;
	// PrintWriter out=HttpServletResponse.getWriter();  
	//Dao class object
	public void init() {
		emp=new empDao();
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req,resp);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=req.getServletPath();
		ServicesServlet.insert(req, resp);
		
		switch(action) {
		case "/saveEmp":
			insert(req, resp);
			break;
			//empDao.empSave(employee);
		
		}
		
		
	}
	
	public static void insert(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("kjsahdjkfhjkl");
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		String city=req.getParameter("city");

empDao e1=new empDao();
		Emp e=new Emp();
		e.setName(name);
		e.setEmail(email);
		e.setPassword(password);
		e.setCity(city);
		
		e1.empSave(e);
		
		resp.sendRedirect("user-form.jsp");
	}
	

	}
