package com.employee;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class empDao {
//	Configuration cfg=new Configuration();
//    cfg.configure("hibernate.cfg.xml");
//	cfg.configure("hibernate.cfg.xml");
//    
//    
//    SessionFactory factory = cfg.buildSessionFactory();
//    
//   
//      Session session = factory.openSession();
//      Transaction tx = session.beginTransaction();
//     
//      session.save(st);
//      tx.commit();
//      session.close();
//	public static SessionFactory configXml() {
//		Configuration cfg=new Configuration();
//		
//		cfg.configure("hibernate.cfg.xml");
//		SessionFactory factory=cfg.buildSessionFactory();
//		return factory;
//		
//	}
	
	
	Configuration  cfg = new Configuration().configure("hibernate.cfg.xml");
	//return new Configuration().configure().buildSessionFactory();
	

	public  void empSave(Emp emp) {
	//	int status=0;
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(emp);
		
		tx.commit();
		session.close();
		//return status;
		
	}
	

}
